/**
 * Tools Module Index
 * 
 * Centralizes all tool exports and provides activation functionality
 */

import * as CodeFixer from './CodeFixer/index.js';
import * as ResponsiveUI from './ResponsiveUI/index.js';
import * as SnapshotCreator from './SnapshotCreator/index.js';
import { activateAllTools } from './toolActivator.js';

// Export all tools
export {
  CodeFixer,
  ResponsiveUI,
  SnapshotCreator
};

// Export all tool activation functions
export const activateTools = async (settings = {}) => {
  console.log('[Tools] Activating all tools...');
  
  const tools = {
    CodeFixer,
    ResponsiveUI,
    SnapshotCreator
  };
  
  const results = await activateAllTools(tools, settings);
  
  console.log('[Tools] Tool activation results:', results);
  return results;
};

// Export event broadcasting functions
export const broadcastSessionStart = (session) => {
  const tools = [CodeFixer, ResponsiveUI, SnapshotCreator];
  
  for (const tool of tools) {
    try {
      if (typeof tool.onSessionStart === 'function') {
        tool.onSessionStart(session);
      }
    } catch (error) {
      console.warn(`[Tools] Error in onSessionStart for tool: ${error.message}`);
    }
  }
};

export const broadcastFileWrite = (event) => {
  const tools = [CodeFixer, ResponsiveUI, SnapshotCreator];
  
  for (const tool of tools) {
    try {
      if (typeof tool.onFileWrite === 'function') {
        tool.onFileWrite(event);
      }
    } catch (error) {
      console.warn(`[Tools] Error in onFileWrite for tool: ${error.message}`);
    }
  }
};

export const broadcastCommand = (command) => {
  const tools = [CodeFixer, ResponsiveUI, SnapshotCreator];
  
  for (const tool of tools) {
    try {
      if (typeof tool.onCommand === 'function') {
        tool.onCommand(command);
      }
    } catch (error) {
      console.warn(`[Tools] Error in onCommand for tool: ${error.message}`);
    }
  }
};
