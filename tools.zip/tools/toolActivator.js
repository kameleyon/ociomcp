/**
 * Tool Activator
 * 
 * Handles tool activation with fallbacks for missing or failing activate functions
 */

/**
 * Activates a tool with fallback handling
 * 
 * @param {Object} tool - The tool module to activate
 * @param {string} toolName - The name of the tool
 * @param {Object} settings - Tool-specific settings
 * @returns {Promise<boolean>} - Success status
 */
export async function activateToolWithFallback(tool, toolName, settings = {}) {
  try {
    // Check if tool has activate function
    if (typeof tool.activate !== 'function') {
      console.warn(`[ToolActivator] Tool '${toolName}' has no activate function, using passive fallback.`);
      // Create passive fallback wrapper
      tool.activate = createPassiveFallback(toolName);
      return await tool.activate(settings);
    }
    
    // Try to activate the tool normally
    return await tool.activate(settings);
    
  } catch (error) {
    console.warn(`[ToolActivator] Failed to activate tool '${toolName}': ${error.message}`);
    console.warn(`[ToolActivator] Using passive fallback for '${toolName}'.`);
    
    // Replace the failing activate with passive fallback
    tool.activate = createPassiveFallback(toolName);
    return await tool.activate(settings);
  }
}

/**
 * Creates a passive fallback activate function
 * 
 * @param {string} toolName - The name of the tool
 * @returns {Function} - Passive fallback activate function
 */
function createPassiveFallback(toolName) {
  return async function passiveFallback() {
    console.warn(`[Tool] ${toolName} activated in passive mode — no active behavior.`);
    return true;
  };
}

/**
 * Ensures a tool has all the necessary hooks
 * 
 * @param {Object} tool - The tool module to check
 * @param {string} toolName - The name of the tool
 */
export function ensureHooks(tool, toolName) {
  // Ensure onSessionStart hook
  if (typeof tool.onSessionStart !== 'function') {
    tool.onSessionStart = function(session) {
      // Optional empty implementation
    };
  }
  
  // Ensure onFileWrite hook
  if (typeof tool.onFileWrite !== 'function') {
    tool.onFileWrite = function(event) {
      // Optional empty implementation
    };
  }
  
  // Ensure onCommand hook
  if (typeof tool.onCommand !== 'function') {
    tool.onCommand = function(command) {
      // Optional empty implementation
    };
  }
}

/**
 * Activates all tools in the given tools object
 * 
 * @param {Object} tools - Object with tool modules
 * @param {Object} settings - Settings for all tools
 * @returns {Promise<Object>} - Activation results
 */
export async function activateAllTools(tools, settings = {}) {
  const results = {};
  
  for (const [toolName, tool] of Object.entries(tools)) {
    // Ensure the tool has all necessary hooks
    ensureHooks(tool, toolName);
    
    // Get tool-specific settings
    const toolSettings = settings[toolName] || {};
    
    // Activate the tool with fallback handling
    try {
      results[toolName] = await activateToolWithFallback(tool, toolName, toolSettings);
    } catch (error) {
      console.error(`[ToolActivator] Critical error activating '${toolName}': ${error.message}`);
      results[toolName] = false;
    }
  }
  
  return results;
}
